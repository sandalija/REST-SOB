package service;

import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("rest/api/v1")
public class RESTapp extends Application {
    
}
