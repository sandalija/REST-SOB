Trobareu dos projectes de NetBeans 8.2:
- El primer, HomeWork1, conté el backend, fet princiaplment a la primera fase
- El segon, SOBASE, conté el frontend

Podeu trobar aquest projecte en el repo de GitHub https://github.com/sandalija/REST-SOB.git

Adjuntem la documentació de la segona convocatoria. Annexada, també la primera fase per si resulta esclaridor-

